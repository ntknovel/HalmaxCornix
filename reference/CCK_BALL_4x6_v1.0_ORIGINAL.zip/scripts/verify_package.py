#!/usr/bin/env python3
"""Static checks for the upload package. This does not compile ZMK."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
variant = "3x6" if "3x6" in ROOT.name else "4x6"
expected_keys = 48 if variant == "3x6" else 60

required = [
    ".github/workflows/build.yml",
    "build.yaml",
    "config/west.yml",
    "config/cck_ball.conf",
    "config/cck_ball.keymap",
    "config/cck_ball.json",
    "config/boards/shields/cck_ball/Kconfig.defconfig",
    "config/boards/shields/cck_ball/Kconfig.shield",
    "config/boards/shields/cck_ball/cck_ball-layouts.dtsi",
    "config/boards/shields/cck_ball/cck_ball.dtsi",
    "config/boards/shields/cck_ball/cck_ball_left.conf",
    "config/boards/shields/cck_ball/cck_ball_left.overlay",
    "config/boards/shields/cck_ball/cck_ball_right.conf",
    "config/boards/shields/cck_ball/cck_ball_right.overlay",
    "config/boards/shields/cck_ball/cck_ball.zmk.yml",
]

errors: list[str] = []

for rel in required:
    if not (ROOT / rel).is_file():
        errors.append(f"missing: {rel}")

common = (ROOT / "config/cck_ball.conf").read_text(encoding="utf-8")
for line in [
    "CONFIG_BT_PERIPHERAL_PREF_MAX_INT=9",
    "CONFIG_BT_PERIPHERAL_PREF_LATENCY=16",
    "CONFIG_BT_BUF_ACL_TX_COUNT=8",
    "CONFIG_BT_L2CAP_TX_BUF_COUNT=32",
    "CONFIG_BT_CTLR_TX_PWR_PLUS_8=y",
    "CONFIG_ZMK_BLE_EXPERIMENTAL_CONN=y",
    "CONFIG_ZMK_BEHAVIORS_QUEUE_SIZE=512",
]:
    if line not in common:
        errors.append(f"missing stability setting: {line}")

data = json.loads((ROOT / "config/cck_ball.json").read_text(encoding="utf-8"))
layout = next(iter(data["layouts"].values()))["layout"]
if len(layout) != expected_keys:
    errors.append(f"JSON layout has {len(layout)} keys, expected {expected_keys}")

physical = (ROOT / "config/boards/shields/cck_ball/cck_ball-layouts.dtsi").read_text(encoding="utf-8")
physical_count = physical.count("&key_physical_attrs")
if physical_count != expected_keys:
    errors.append(f"physical layout has {physical_count} keys, expected {expected_keys}")

dtsi = (ROOT / "config/boards/shields/cck_ball/cck_ball.dtsi").read_text(encoding="utf-8")
rc_count = len(re.findall(r"\bRC\(", dtsi))
if rc_count != expected_keys:
    errors.append(f"matrix transform has {rc_count} RC entries, expected {expected_keys}")

for rel in [
    "config/cck_ball.keymap",
    "config/boards/shields/cck_ball/cck_ball-layouts.dtsi",
    "config/boards/shields/cck_ball/cck_ball.dtsi",
    "config/boards/shields/cck_ball/cck_ball_left.overlay",
    "config/boards/shields/cck_ball/cck_ball_right.overlay",
]:
    text = (ROOT / rel).read_text(encoding="utf-8")
    if text.count("{") != text.count("}"):
        errors.append(f"unbalanced braces: {rel}")

if errors:
    print("STATIC VALIDATION FAILED")
    for err in errors:
        print(f"- {err}")
    sys.exit(1)

print(f"STATIC VALIDATION PASSED: {variant}, {expected_keys} physical keys")
print("Note: a real ZMK compile must still be completed by GitHub Actions.")
