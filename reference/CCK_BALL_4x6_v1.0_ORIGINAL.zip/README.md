# CCK-BALL 4x6 — Keyball식 연결 안정화판

이 저장소는 **CCK-BALL 4x6 / 60키(4×6 계열)** 공개 ZMK 구성을 기준으로,
Wireless Keyball 61에서 확인되는 BLE 안정화 설정을 선별 이식한 GitHub Actions 빌드용 소스입니다.

## 핵심 변경

- PC 연결 선호값: 7.5–11.25 ms, latency 16, timeout 4초
- Bluetooth ACL 송신 버퍼: 8
- Bluetooth 이벤트 수신 버퍼: 10
- L2CAP 송신 버퍼: 32
- nRF52840 송신 출력: +8 dBm
- `CONFIG_ZMK_BLE_EXPERIMENTAL_CONN=y` 활성화
- 복합 behavior 큐: 512
- 분할 보조부 배터리 조회/프록시 활성화
- Keyball에서 쓰는 PMW3610 downshift/sample/automouse 시간 중
  **현재 CCK 드라이버가 실제 지원하는 값만** 적용

## 그대로 유지한 것

- CCK-BALL의 핀 배치, 행렬, 좌우 역할
- 오른쪽 central / 왼쪽 peripheral 구조
- 원래 키맵과 레이어
- 양쪽 인코더 설정
- CCK 전용 PMW3610 방향, CPI, 스크롤 값
- ZMK Studio
- `imhy123/zmk`의 `v0.3-branch`
- DoctorWangWang PMW3610 드라이버

트랙볼 드라이버를 Keyball용으로 강제 교체하거나 deep sleep을 기본 활성화하지 않았습니다.
그 두 변경은 CCK 하드웨어에서 트랙볼 깨짐이나 ‘잠든 뒤 안 깨어나는 현상’을 만들 수 있어
연결 안정화판의 기본값으로는 부적합합니다.

## GitHub에 올리는 순서

1. 이 ZIP의 압축을 풉니다.
2. GitHub에서 빈 저장소를 하나 만듭니다.
3. 압축을 푼 폴더 **안의 내용 전체**를 저장소 루트에 업로드합니다.
   `.github`, `config`, `docs`, `scripts`, `build.yaml`이 같은 깊이에 있어야 합니다.
4. Commit합니다.
5. 저장소의 **Actions** 탭에서
   **Build CCK-BALL Keyball-style stable firmware**를 엽니다.
6. 자동 빌드가 시작되지 않았다면 **Run workflow**를 누릅니다.
7. 모든 작업이 성공하면 실행 화면 아래의 `firmware` artifact를 받습니다.

생성물에는 이름에 다음 문자열이 들어간 UF2가 있어야 합니다.

- `cck_ball_left`
- `cck_ball_right`
- `settings_reset`

## 플래시

- 왼쪽 보드에는 `cck_ball_left` UF2
- 오른쪽 보드에는 `cck_ball_right` UF2
- CCK-BALL은 **오른쪽이 central**이므로 PC·ZMK Studio 연결도 오른쪽이 담당합니다.
- 공통 BLE 설정이 바뀌므로 좌우를 모두 업데이트합니다.

처음에는 `settings_reset` 없이 좌우 펌웨어만 올려 기존 설정을 보존해 시험할 수 있습니다.
기존 페어링 캐시 때문에 연결이 이상하면 `docs/BUILD_FLASH_KO.md`의 초기화 절차를 따르세요.

## 확인 파일

- 변경 세부사항: `docs/CHANGES_KO.md`
- 빌드·플래시 상세 절차: `docs/BUILD_FLASH_KO.md`
- 증상별 점검: `docs/TROUBLESHOOTING_KO.md`
- 정적 검증 결과: `VALIDATION_REPORT.txt`
- 출처: `SOURCE_ATTRIBUTION.md`
