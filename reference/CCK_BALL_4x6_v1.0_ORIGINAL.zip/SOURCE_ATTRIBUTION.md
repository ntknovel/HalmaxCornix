# Source attribution

This package is a modified ZMK user configuration assembled from public source
files and settings.

## CCK-BALL base

- Repository: https://github.com/weekinro/CCK-BALL
- Source branches:
  - CCK-BALL-4x6
  - CCK-BALL-3x6
- Hardware matrix, overlays, keymaps, encoder settings, build matrix, and the
  DoctorWangWang PMW3610 integration are derived from those branches.

## Keyball 61 reference

- Repository: https://github.com/tangbonze/zmk-config-Keyball61
- BLE connection preferences, Bluetooth buffer sizes, experimental connection
  profile, behavior queue size, split battery proxy, and supported PMW3610
  timing values were used as the comparison target.

## Firmware and driver dependencies

- ZMK fork: https://github.com/imhy123/zmk, branch `v0.3-branch`
- PMW3610 driver: https://github.com/DoctorWangWang/zmk-pmw3610-driver,
  branch `main`
- GitHub reusable workflow:
  `zmkfirmware/zmk/.github/workflows/build-user-config.yml@v0.3`

Existing SPDX headers are retained in device-tree files. Review upstream
licenses before redistributing a commercial derivative.
