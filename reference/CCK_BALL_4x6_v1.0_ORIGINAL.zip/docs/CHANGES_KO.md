# 변경 사항

## 1. Keyball 61에서 이식한 공통 설정

`config/cck_ball.conf`

```ini
CONFIG_BT_PERIPHERAL_PREF_MIN_INT=6
CONFIG_BT_PERIPHERAL_PREF_MAX_INT=9
CONFIG_BT_PERIPHERAL_PREF_LATENCY=16
CONFIG_BT_PERIPHERAL_PREF_TIMEOUT=400

CONFIG_BT_BUF_ACL_TX_COUNT=8
CONFIG_BT_BUF_EVT_RX_COUNT=10
CONFIG_BT_L2CAP_TX_BUF_COUNT=32

CONFIG_BT_CTLR_TX_PWR_PLUS_8=y
CONFIG_ZMK_BLE_EXPERIMENTAL_CONN=y
CONFIG_ZMK_BEHAVIORS_QUEUE_SIZE=512

CONFIG_ZMK_SPLIT_BLE_CENTRAL_BATTERY_LEVEL_FETCHING=y
CONFIG_ZMK_SPLIT_BLE_CENTRAL_BATTERY_LEVEL_PROXY=y
```

## 2. 오른쪽 트랙볼 설정

`config/boards/shields/cck_ball/cck_ball_right.conf`

기존 CCK-BALL의 CPI·방향·스크롤·125 Hz 소프트웨어 폴링은 유지했습니다.
아래의 Keyball식 시간 설정만 추가했습니다.

```ini
CONFIG_PMW3610_RUN_DOWNSHIFT_TIME_MS=3264
CONFIG_PMW3610_REST1_SAMPLE_TIME_MS=20
CONFIG_PMW3610_AUTOMOUSE_TIMEOUT_MS=700
```

## 3. 적용하지 않은 Keyball 설정

### Keyball의 PMW3610 드라이버로 교체

적용하지 않았습니다. CCK-BALL 공개 소스는 DoctorWangWang 드라이버와
`pixart,pmw3610` 노드, CCK용 저속·인코더 변경에 맞춰져 있습니다.
Keyball 드라이버에는 CCK 드라이버에 없는 `PMW3610_PM`,
`MOVEMENT_THRESHOLD` 등이 있으므로 설정만 복사하면 Kconfig 경고 또는 빌드 실패가 납니다.

### Deep sleep

기본 비활성화했습니다.

```ini
# CONFIG_ZMK_SLEEP=y
# CONFIG_ZMK_IDLE_SLEEP_TIMEOUT=900000
```

연결 안정성 시험에서 15분 뒤 의도적인 절전 진입을 ‘또 끊겼다’고 오인할 수 있고,
현재 CCK 트랙볼 드라이버는 Keyball의 PM suspend/resume 기능을 갖고 있지 않습니다.

### 좌우 split latency 0

Keyball 61도 좌우 split의 기본 latency 30을 그대로 사용하므로 넣지 않았습니다.
이 설정은 배터리 소모를 늘리며 Keyball 동작을 재현하는 변경도 아닙니다.
