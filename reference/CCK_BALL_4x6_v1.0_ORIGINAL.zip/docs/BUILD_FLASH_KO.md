# GitHub 빌드와 플래시

## A. GitHub 웹 업로드

저장소 루트는 다음 모양이어야 합니다.

```text
.github/
  workflows/
    build.yml
config/
  boards/
  cck_ball.conf
  cck_ball.keymap
  cck_ball.json
  west.yml
build.yaml
README.md
```

ZIP 바깥쪽 폴더 자체를 한 단계 더 넣지 말고, 위 항목들이 저장소 첫 화면에 보여야 합니다.

## B. Actions 빌드

1. **Actions** 탭을 엽니다.
2. 처음 사용하는 저장소라면 workflow 실행을 허용합니다.
3. **Build CCK-BALL Keyball-style stable firmware**를 선택합니다.
4. **Run workflow**를 누릅니다.
5. Build가 모두 초록색인지 확인합니다.
6. 하단 Artifacts의 `firmware`를 받습니다.

왼쪽, 오른쪽, settings reset의 세 대상 중 하나라도 실패하면 플래시하지 말고
실패 로그에서 첫 번째 `error:` 또는 `warning:` 주변을 확인합니다.

## C. 기존 설정을 보존하는 1차 시험

1. 현재 순정/기존 좌우 UF2와 키맵을 백업합니다.
2. 왼쪽에 `cck_ball_left` UF2를 기록합니다.
3. 오른쪽에 `cck_ball_right` UF2를 기록합니다.
4. 양쪽 전원을 껐다 켭니다.
5. 기존 Windows Bluetooth 항목으로 연결되는지 확인합니다.

## D. 완전 초기화가 필요한 경우

다음 상황에서만 진행합니다.

- Windows가 예전 GATT/페어링 정보를 계속 사용함
- 왼쪽이 오른쪽에 붙지 않음
- 한쪽만 옛 펌웨어의 bond를 유지함
- ZMK Studio 저장 키맵을 지워도 됨

순서:

1. Windows에서 기존 CCK-BALL Bluetooth 장치를 제거합니다.
2. `settings_reset` UF2를 왼쪽에 기록하고 잠시 부팅합니다.
3. `settings_reset` UF2를 오른쪽에 기록하고 잠시 부팅합니다.
4. 왼쪽에 `cck_ball_left` UF2를 다시 기록합니다.
5. 오른쪽에 `cck_ball_right` UF2를 다시 기록합니다.
6. 양쪽 전원을 껐다 켭니다.
7. 오른쪽 central을 Windows와 새로 페어링합니다.

`settings_reset`은 Bluetooth bond와 ZMK Studio에서 저장한 동적 설정을 지울 수 있습니다.
